<template>
  <el-config-provider :locale="locale">
    <Menu />
    <router-view></router-view>
  </el-config-provider>
</template>
<script lang="ts" setup>
import { ref } from "vue";
import zhCn from "element-plus/lib/locale/lang/zh-cn";
import Menu from "@bizCmp/Menu.vue";

const locale = ref(zhCn);
</script>

<style lang="sass">
@import '@/assets/sass'



#app
  height: 100%
  font-family: Avenir, Helvetica, Arial, sans-serif
  -webkit-font-smoothing: antialiased
  -moz-osx-font-smoothing: grayscale
  // background: url('@viewsImg/Index/bg.png') 0 0 no-repeat
  // display: flex
  &>div:nth-child(2)
    height: 100%
</style>

<style scoped lang="sass">
// .g-df
//  display: flex
</style>
