<template>
  <div class="menu-box">
    <div class="menu-pull"></div>
    <el-row class="tac">
      <el-col>
        <el-menu
          :router="true"
          background-color="#022058"
          text-color="rgba(255,255,255,0.65)"
          active-text-color="#fff"
          :default-active="defaultActive"
          :default-openeds="[]"
          class="el-menu-vertical-demo"
          @open="handleOpen"
          @close="handleClose"
        >
          <template v-for="(item, index) in menuList" :key="index">
            <el-sub-menu
              v-if="item.children && item.children.length"
              :index="item.index"
            >
              <template #title>
                <!-- <el-icon><location /></el-icon> -->
                <el-icon
                  ><img src="~@viewsImg/Index/menu-title-icon.png" alt=""
                /></el-icon>
                <span>{{ item.name }}</span>
              </template>
              <el-menu-item
                v-for="(t, i) in item.children"
                :key="i"
                :index="t.path"
                :route="t.path"
                >{{ t.name }}</el-menu-item
              >
            </el-sub-menu>

            <template v-else>
              <el-menu-item :index="item.name">
                <el-icon><document /></el-icon>
                <span>{{ item.name }}</span>
              </el-menu-item>
            </template>
          </template>

          <!-- <el-sub-menu index="1">
            <template #title>
              <el-icon
                ><img src="~@viewsImg/Index/menu-title-icon.png" alt=""
              /></el-icon>
              <span>Navigator One</span>
            </template>
            <el-menu-item index="1-1">item one</el-menu-item>
            <el-menu-item index="1-2">item two</el-menu-item>
          </el-sub-menu>
          <el-menu-item index="2">
            <template #title>
              <el-icon><icon-menu /></el-icon>
              <span>Navigator Two</span>
            </template>
          </el-menu-item>
          <el-menu-item index="3" disabled>
            <el-icon><document /></el-icon>
            <span>Navigator Three</span>
          </el-menu-item>
          <el-menu-item index="4">
            <el-icon><setting /></el-icon>
            <span>Navigator Four</span>
          </el-menu-item> -->
        </el-menu>
      </el-col>
    </el-row>
  </div>
</template>

<script lang="ts" setup>
import { Document } from "@element-plus/icons-vue";
import { computed, ref } from "vue";

import { useRouter } from "vue-router";
import { MenuOption } from "@bizType/index.ts";

const router = useRouter();

const isCollapse = ref(true);
const menuList = [
  {
    name: "市场看板",
    index: "marketKanban",
    children: [
      {
        name: "平衡分析",
        path: "/equilibrium-analysis",
      },
      {
        name: "外购电决策",
        path: "/purchased-electricity",
      },
    ],
  },
];

const defaultActive = computed(() => {
  console.log(router.currentRoute.value.path);
  return router.currentRoute.value.path;
});
const handleOpen = (key: string, keyPath: string[]) => {
  console.log(key, keyPath);
};
const handleClose = (key: string, keyPath: string[]) => {
  console.log(key, keyPath);
};


</script>

<style lang="sass" scoped>
.menu-box
  min-width: 268px
  position: absolute
  left: -256px
  transition: all 0.3s
  height: 100%
  transition: all 0.3s
  &:hover
    left: 0px

  &:hover .menu-pull
    left: -12px


  .menu-pull
    width: 12px
    height: 320px
    position: absolute
    right: 0px
    top: 50%
    transform: translateY(-50%)
    background: url('@viewsImg/Index/menu-pull.png')

  .tac:deep()
    width: 256px
    height: 100%

    .el-menu
      // background: #022058 !important
      border-right: 0px
      height: 100% !important

    .el-menu--inline
      background: #0b1c3d

      .el-menu-item
        padding-left: 50px !important

        &:hover
          color: #fff !important

      .el-menu-item.is-active
        background: rgba(24,144,255,.3) !important
</style>
