import { title } from 'process';
<template>
  <div class="item-title">
    <span>{{ title }}</span>
  </div>
</template>
<script lang="ts" setup>
import { defineProps } from "vue";

const props = defineProps({
  title: String
});
</script>
<style lang="sass" scoped>
.item-title
  width: 518px
  height: 37px
  background: url('@archImg/item-title.png')
  background-size: 100% 100%
  background-repeat: no-repeat
  span
    // background: linear-gradient(180deg,#ffffff, #9fdbee 48%, #009fd2)
    margin-left: 37px
    font-size: 18px
    // font-family: PingFangSC, PingFangSC-Semibold
    font-weight: 600
    text-align: left
    color: #56f4fe
    line-height: 37px
    // text-shadow: 0px 2px 9px 0px rgba(0,95,114,0.89)
</style>
