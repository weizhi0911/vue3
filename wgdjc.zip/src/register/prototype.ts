// import { createApp } from 'vue'
// import ElementPlus from 'element-plus'
// // 将echarts 挂载到Vue3原型
// import * as echarts from 'echarts' 
// import App from '../App.vue'

// import 'element-plus/dist/index.css'


// const app = createApp(App)

// // 全局方法
// app.config.globalProperties.$echarts = echarts
// app.use(ElementPlus as any)
