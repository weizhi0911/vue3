// 具体业务自定义变量类型声明入口，适用于确定的变量类型
export type MenuOption = {
  name:string
  path?:string
}