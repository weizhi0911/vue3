<template>
  <div>平衡分析</div>
</template>
