<template>
  <div class="purchased-electricity">
    <div class="head">
      <span>外购电决策</span>
    </div>

    <div class="purchased-box">
      <div class="purchased-left">
        <div class="my-date">
          <el-date-picker
            type="date"
            placeholder="请选择时间"
            format="YYYY-MM-DD"
            value-format="YYYY-MM-DD"
          >
          </el-date-picker>
        </div>

        <div>
          <ItemTitle :title="'降低购电成本'" />
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { ref } from "vue";
let date = ref("");
</script>
<!-- 
<script>
  export default {
  name: "PurchasedElectricity",
  setup() {}
}
</script> -->

<style lang="sass" scoped>
.purchased-electricity
  width: 100%
  background: url('@viewsImg/Index/bg-2.png')
  background-size: 100% 100%
  background-repeat: no-repeat

  .head
    width: 100%
    text-align: center
    height: 78px
    background: url('@viewsImg/Index/head.png')
    background-size: 100% 100%
    background-repeat: no-repeat
    span
      font-size: 30px
      color: #56f4fe
      line-height: 52px
      letter-spacing: 6px
      text-shadow: 0px 2px 9px 0px rgba(0,12,14,0.89)
  .purchased-box
    padding: 0px 24px
    box-sizing: border-box

    .my-date:deep()
      .el-input__wrapper
        background: rgba(0,169,250,0.20) !important
        box-shadow: none
        .el-input__prefix
          // display: none
        .el-input__inner
          color: #e6f0ff !important
          font-size: 14px !important
</style>
